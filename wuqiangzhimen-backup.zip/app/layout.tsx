import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Newsroom Studio · 报纸排版工具",
  description: "粘贴文章，自动生成经典报纸版式。",
  icons: {
    icon: "/favicon.svg",
    shortcut: "/favicon.svg",
  },
  manifest: "/manifest.webmanifest",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="zh-CN">
      <body>{children}</body>
    </html>
  );
}
