"use client";

import { ChangeEvent, useEffect, useMemo, useRef, useState } from "react";
import html2canvas from "html2canvas";
import { jsPDF } from "jspdf";

const starter = `市场在不确定性中寻找新的定价锚点

投资者正在重新评估增长、通胀与利率之间的微妙平衡。过去数周，风险资产的波动并未削弱企业扩张的意愿，反而让管理层更强调现金流与执行效率。

在上海、纽约与伦敦，交易员把目光投向即将公布的宏观数据。对长期投资者而言，真正重要的并不是某一个数字，而是数据背后趋势是否会改变。

“当预期变得拥挤，耐心本身就是一种优势。”一位资深基金经理表示。`;

const mapStarter = `# 品牌增长计划
## 内容策略
- 深度报道
- 每周通讯
## 产品体验
- 编辑器优化
- 移动端使用
## 分发渠道
- 社交媒体
- 合作伙伴`;

const defaultPaper = { name: "THE FINANCIAL JOURNAL", established: "EST. 2026", region: "亚洲", kicker: "商业与市场", section: "深度报道", deck: "用清晰、克制的报纸版式，让每一段重要叙述都有呼吸的空间。", author: "记者：编辑部", date: "2026 年 8 月 11 日", reading: "阅读 4 分钟", footerName: "THE FINANCIAL JOURNAL", footerNote: "© 2026 · 专为清晰表达而设计", page: "第 01 页" };
type PaperKey = keyof typeof defaultPaper;

function parseMap(markdown: string) {
  let root = "思维导图"; const branches: { title: string; items: string[] }[] = []; let active = -1; let hasRoot = false;
  markdown.split("\n").forEach((raw) => {
    const indent = raw.length - raw.trimStart().length; const line = raw.trim(); if (!line) return;
    if (/^#\s+/.test(line)) { root = line.replace(/^#\s+/, ""); hasRoot = true; }
    else if (/^##\s+/.test(line) || (/^[-*+]\s+/.test(line) && indent === 0)) { branches.push({ title: line.replace(/^(?:##\s+|[-*+]\s+)/, ""), items: [] }); active = branches.length - 1; }
    else if (/^(?:###\s+|[-*+]\s+)/.test(line)) { if (active < 0) { branches.push({ title: "要点", items: [] }); active = 0; } branches[active].items.push(line.replace(/^(?:###\s+|[-*+]\s+)/, "")); }
    else if (!hasRoot) { root = line; hasRoot = true; }
    else { if (active < 0) { branches.push({ title: line, items: [] }); active = branches.length - 1; } else branches[active].items.push(line); }
  });
  return { root, branches: branches.length ? branches : [{ title: "开始", items: ["在左侧输入 Markdown"] }] };
}

function EditText({ value, set, className = "" }: { value: string; set: (value: string) => void; className?: string }) {
  return <span className={`editable-text ${className}`} contentEditable suppressContentEditableWarning role="textbox" onInput={(e) => set(e.currentTarget.textContent || "")}>{value}</span>;
}

export default function Home() {
  const [mode, setMode] = useState<"news" | "writer" | "map">("news");
  const [article, setArticle] = useState(starter); const [headline, setHeadline] = useState("市场在不确定性中寻找新的定价锚点");
  const [columns, setColumns] = useState(3); const [edition, setEdition] = useState("晨间版"); const [paper, setPaper] = useState(defaultPaper);
  const [imageUrls, setImageUrls] = useState(["", "", ""]); const [activeImageSlot, setActiveImageSlot] = useState(0); const newsFile = useRef<HTMLInputElement>(null);
  const [writerTitle, setWriterTitle] = useState("一篇值得被好好阅读的文章"); const [writerText, setWriterText] = useState(starter); const [writerImage, setWriterImage] = useState(""); const writerFile = useRef<HTMLInputElement>(null);
  const [markdown, setMarkdown] = useState(mapStarter); const [mapStyle, setMapStyle] = useState<"normal" | "relation" | "split">("normal");
  useEffect(() => { if ("serviceWorker" in navigator) navigator.serviceWorker.register("/sw.js"); }, []);
  const newsPaper = useRef<HTMLElement>(null); const writerCard = useRef<HTMLElement>(null); const mapCanvas = useRef<HTMLDivElement>(null);
  const paragraphs = useMemo(() => article.split(/\n\s*\n/).map((p) => p.trim()).filter(Boolean), [article]);
  const sections = useMemo(() => { const size = Math.max(1, Math.ceil(paragraphs.length / 3)); return [paragraphs.slice(0, size), paragraphs.slice(size, size * 2), paragraphs.slice(size * 2)]; }, [paragraphs]);
  const map = useMemo(() => parseMap(markdown), [markdown]);
  const updatePaper = (key: PaperKey, text: string) => setPaper((p) => ({ ...p, [key]: text }));
  const updateParagraph = (section: number, index: number, text: string) => { const next = sections.map((x) => [...x]); next[section][index] = text.trim(); setArticle(next.flat().filter(Boolean).join("\n\n")); };
  const chooseImage = (event: ChangeEvent<HTMLInputElement>, writer = false) => { const file = event.target.files?.[0]; if (!file?.type.startsWith("image/")) return; const reader = new FileReader(); reader.onload = () => writer ? setWriterImage(String(reader.result)) : setImageUrls((old) => old.map((url, i) => i === activeImageSlot ? String(reader.result) : url)); reader.readAsDataURL(file); };
  const imageSlot = (slot: number, label: string) => { const url = imageUrls[slot]; return <button className={`image-slot article-image ${url ? "has-image" : ""}`} onClick={() => { setActiveImageSlot(slot); newsFile.current?.click(); }}><>{url ? <img src={url} alt={label} /> : <><div className="image-lines" /><div><b>点击上传{label}</b><small>3:4 竖版图片</small></div></>} {url && <span className="change-image">更换图片</span>}</></button>; };
  const capture = async (element: HTMLElement | null) => element ? html2canvas(element, { scale: 2, backgroundColor: "#f7f3e9", useCORS: true, windowWidth: element.scrollWidth, windowHeight: element.scrollHeight }) : null;
  const download = (blob: Blob, fileName: string) => { const link = document.createElement("a"); const url = URL.createObjectURL(blob); link.download = fileName; link.href = url; document.body.appendChild(link); link.click(); link.remove(); setTimeout(() => URL.revokeObjectURL(url), 1000); };
  const exportLongImage = async (element: HTMLElement | null, fileName: string) => { const canvas = await capture(element); if (!canvas) return; canvas.toBlob((blob) => { if (blob) download(blob, `${fileName}.png`); }, "image/png"); };
  const exportPdf = async (element: HTMLElement | null, fileName: string) => { const canvas = await capture(element); if (!canvas) return; const pdf = new jsPDF({ orientation: canvas.width > canvas.height ? "landscape" : "portrait", unit: "px", format: [canvas.width, canvas.height], compress: true }); pdf.addImage(canvas.toDataURL("image/jpeg", 0.95), "JPEG", 0, 0, canvas.width, canvas.height); pdf.save(`${fileName}.pdf`); };
  const exportActions = (getElement: () => HTMLElement | null, fileName: string) => <div className="export-actions"><button onClick={() => exportPdf(getElement(), fileName)}>下载 PDF</button><button onClick={() => exportLongImage(getElement(), fileName)}>下载长图</button></div>;

  return <main className="app-shell">
    <nav className="app-nav"><div className="brand"><span className="brand-mark">N</span><span>Newsroom Studio</span></div><div className="nav-tabs">{([['news','新闻排版'],['writer','写文章'],['map','思维导图']] as const).map(([key,label]) => <button key={key} className={mode === key ? 'active' : ''} onClick={() => setMode(key)}>{label}</button>)}</div></nav>
    {mode === "news" && <div className="studio-shell">
      <aside className="controls"><div className="rail-label">新闻编辑台</div><label className="field-label">报纸名称<input value={paper.name} onChange={(e) => updatePaper("name", e.target.value)} /></label><label className="field-label">版次<select value={edition} onChange={(e) => setEdition(e.target.value)}><option>晨间版</option><option>午间版</option><option>周末版</option></select></label><label className="field-label">主标题<input value={headline} onChange={(e) => setHeadline(e.target.value)} /></label><label className="field-label">文章内容<textarea value={article} onChange={(e) => setArticle(e.target.value)} /></label><div className="field-label">版式栏数<div className="segmented">{[2,3,4].map((n) => <button key={n} className={columns === n ? "selected" : ""} onClick={() => setColumns(n)}>{n} 栏</button>)}</div></div><p className="rail-note">纸面上的每一段文字都可直接点击修改。三处图片均为 3:4 竖版。</p></aside>
      <section className="canvas-area"><header className="workspace-header"><span>新闻排版预览</span>{exportActions(() => newsPaper.current, "新闻排版")}</header><article ref={newsPaper} className="newspaper"><span className="watermark">无墙之门</span><div className="masthead"><EditText value={paper.established} set={(x) => updatePaper("established", x)} /><strong><EditText value={paper.name} set={(x) => updatePaper("name", x)} /></strong><span>{edition} · <EditText value={paper.region} set={(x) => updatePaper("region", x)} /></span></div><div className="rule"/><div className="kicker"><EditText value={paper.kicker} set={(x) => updatePaper("kicker", x)} /> <i>/</i> <EditText value={paper.section} set={(x) => updatePaper("section", x)} /></div><h1 className="editable-headline" contentEditable suppressContentEditableWarning onInput={(e) => setHeadline(e.currentTarget.textContent || "")}>{headline}</h1><p className="deck"><EditText value={paper.deck} set={(x) => updatePaper("deck", x)} /></p><div className="byline"><EditText value={paper.author} set={(x) => updatePaper("author", x)} /><EditText value={paper.date} set={(x) => updatePaper("date", x)} /><EditText value={paper.reading} set={(x) => updatePaper("reading", x)} /></div><input ref={newsFile} className="image-input" type="file" accept="image/*" onChange={(e) => chooseImage(e)} />{imageSlot(0,"开篇主图")}{sections.map((section, si) => <div key={si}><div className="article-columns" style={{columnCount:columns}}>{section.map((p,i) => <p key={i} className={`${si === 0 && i === 0 ? "lead " : ""}editable-paragraph`} contentEditable suppressContentEditableWarning onBlur={(e) => updateParagraph(si,i,e.currentTarget.textContent || "")}>{p}</p>)}</div>{si < 2 && imageSlot(si+1,si === 0 ? "中段配图" : "结尾前配图")}</div>)}<footer className="paper-footer"><EditText value={paper.footerName} set={(x) => updatePaper("footerName", x)} /><EditText value={paper.footerNote} set={(x) => updatePaper("footerNote", x)} /><EditText value={paper.page} set={(x) => updatePaper("page", x)} /></footer></article></section>
    </div>}
    {mode === "writer" && <div className="writer-shell"><aside className="controls"><div className="rail-label">写文章</div><label className="field-label">标题<input value={writerTitle} onChange={(e) => setWriterTitle(e.target.value)} /></label><label className="field-label">文章<textarea value={writerText} onChange={(e) => setWriterText(e.target.value)} /></label><p className="rail-note">粘贴文章后自动形成一张可打印的竖版文章卡。</p></aside><section className="writer-area"><header className="workspace-header"><span>3:4 文章版</span>{exportActions(() => writerCard.current, "写文章")}</header><article ref={writerCard} className="story-card"><input ref={writerFile} className="image-input" type="file" accept="image/*" onChange={(e) => chooseImage(e,true)} /><button className={`story-image ${writerImage ? "has-image" : ""}`} onClick={() => writerFile.current?.click()}>{writerImage ? <img src={writerImage} alt="文章主图"/> : <><b>点击上传主图</b><small>3:4 竖版图片</small></>}</button><div className="story-copy"><div className="story-kicker" contentEditable suppressContentEditableWarning>STORY / NOTES</div><h1 contentEditable suppressContentEditableWarning onInput={(e) => setWriterTitle(e.currentTarget.textContent || "")}>{writerTitle}</h1><div className="story-body" contentEditable suppressContentEditableWarning onBlur={(e) => setWriterText(e.currentTarget.textContent || "")}>{writerText.split(/\n\s*\n/).map((p,i) => <p key={i}>{p}</p>)}</div></div></article></section></div>}
    {mode === "map" && <div className="map-shell"><aside className="controls"><div className="rail-label">Markdown 思维导图</div><label className="field-label">Markdown<textarea value={markdown} onChange={(e) => setMarkdown(e.target.value)} /></label><button className="sample-button" onClick={() => setMarkdown((source) => `${source} `)}>更新导图</button><div className="field-label">布局方式<div className="segmented map-switch">{([['normal','分支'],['relation','关系'],['split','左右']] as const).map(([key,label]) => <button key={key} className={mapStyle === key ? "selected" : ""} onClick={() => setMapStyle(key)}>{label}</button>)}</div></div><p className="rail-note">分支图显示主线与子线；人物关系图将中心主题与所有分支相连。</p></aside><section className="map-area"><header className="workspace-header"><span>{mapStyle === "relation" ? "人物关系图" : "思维导图"}</span>{exportActions(() => mapCanvas.current, "思维导图")}</header><div ref={mapCanvas} className={`mind-canvas ${mapStyle}`}><div className="map-root">{map.root}</div><div className="map-branches">{map.branches.map((branch,i) => <div key={`${branch.title}-${i}`} className="map-branch"><div className="branch-title">{branch.title}</div>{branch.items.map((item,j) => <div className="leaf" key={`${item}-${j}`}>{item}</div>)}</div>)}</div></div></section></div>}
  </main>;
}
